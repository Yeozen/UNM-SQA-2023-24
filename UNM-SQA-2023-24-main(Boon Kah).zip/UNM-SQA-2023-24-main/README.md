# UNM-SQA-2023-24
 Build an application (web or desktop based) whose main user interface displays a collection of 12 short YouTube videos on the topic of “Software Quality Assurance”.

Each member in the group has individual branch, main branch is still empty because we have not finialize the code yet. Please choose one of the branch to compile.
